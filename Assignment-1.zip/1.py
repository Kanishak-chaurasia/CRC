N = 4
for i in range(N):
    for j in range(i+1):
        print("*", end=" ")
    print()