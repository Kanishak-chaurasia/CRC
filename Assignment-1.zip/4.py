M = 4
for i in range(M):
    for j in range(M-i):
        print("*", end=' ')
    print()