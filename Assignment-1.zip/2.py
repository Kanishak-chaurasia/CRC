n = 4
x = 1
for r in range(1, n+1):
    for c in range(1, r+1):
        print(x, end=' ')
        x += 1
    print()